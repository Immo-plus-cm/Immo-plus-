IMMO+ — PACK RECHERCHE IMMOBILIÈRE SUR DEMANDE (corrigé)

CONTENU
- index.html : inscription/connexion, formulaire de demande, suivi, messagerie et espace administrateur.
- schema.sql : tables demands/messages et politiques RLS.
- README.txt : installation et tests.

ATTENTION — COMPATIBILITÉ
Ce pack utilise la table public.profiles existante avec les colonnes id, nom_complet et type_compte (valeur admin pour le compte administrateur). Il ne remplace pas les tables logements, déblocage contact ou les autres modules Immo+.
Le SQL crée demands et messages si elles n'existent pas. Si l'une de ces tables existe déjà avec une structure différente, ne lance pas le script avant vérification : CREATE TABLE IF NOT EXISTS ne modifie pas une table existante.

INSTALLATION
1. Dans Supabase > SQL Editor, exécute schema.sql.
2. Dans index.html, remplace VOTRE_SUPABASE_URL et VOTRE_CLE_PUBLISHABLE par l'URL et la clé publishable du projet Supabase utilisé par Immo+.
3. N'utilise jamais la clé service_role dans le code du navigateur.
4. Publie index.html à la racine de l'hébergement.
5. Crée un compte depuis le site. Vérifie qu'il apparaît dans public.profiles.
6. Pour attribuer les droits admin, décommente et adapte la dernière commande de schema.sql avec l'adresse exacte du compte, puis exécute-la séparément. Déconnecte-toi et reconnecte-toi.

TESTS
- Un utilisateur connecté crée une demande et ne voit que ses demandes.
- L'administrateur voit toutes les demandes, modifie leur statut et répond.
- Le demandeur et l'administrateur échangent dans la conversation privée.

LIMITES
Pas de paiement, notifications push/e-mail ni messagerie temps réel. Les messages sont rechargés à l'ouverture de la conversation ou après envoi.
