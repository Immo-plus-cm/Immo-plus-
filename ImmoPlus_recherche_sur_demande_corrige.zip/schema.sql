-- IMMO+ | Recherche immobilière sur demande
-- Adapté à public.profiles existante : id, nom_complet, type_compte.
-- À exécuter dans Supabase > SQL Editor. Ne jamais exposer service_role dans le navigateur.
create extension if not exists pgcrypto;

-- Trigger dédié : ne remplace pas le trigger éventuellement utilisé par les autres modules.
create or replace function public.immo_create_profile_for_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles (id, nom_complet)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name', ''))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists immo_profile_after_signup on auth.users;
create trigger immo_profile_after_signup after insert on auth.users
for each row execute function public.immo_create_profile_for_new_user();

create table if not exists public.demands (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  city text not null,
  neighborhoods text,
  property_type text not null,
  rooms text,
  budget_min bigint,
  budget_max bigint not null,
  move_in_date date,
  details text,
  status text not null default 'received'
    check (status in ('received','searching','proposals','completed','cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint immo_demands_budget_valid check (budget_min is null or budget_min <= budget_max)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  demand_id uuid not null references public.demands(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  content text not null check (char_length(content) between 1 and 4000),
  created_at timestamptz not null default now()
);

create index if not exists immo_demands_user_created_idx on public.demands(user_id, created_at desc);
create index if not exists immo_messages_demand_created_idx on public.messages(demand_id, created_at);

create or replace function public.is_immo_admin()
returns boolean language sql stable security definer set search_path = public
as $$
  select exists (select 1 from public.profiles p where p.id = auth.uid() and p.type_compte = 'admin');
$$;

alter table public.profiles enable row level security;
alter table public.demands enable row level security;
alter table public.messages enable row level security;

drop policy if exists "immo profile read own" on public.profiles;
create policy "immo profile read own" on public.profiles for select to authenticated
using (id = auth.uid() or public.is_immo_admin());

drop policy if exists "immo demand read owner admin" on public.demands;
create policy "immo demand read owner admin" on public.demands for select to authenticated
using (user_id = auth.uid() or public.is_immo_admin());

drop policy if exists "immo demand create own" on public.demands;
create policy "immo demand create own" on public.demands for insert to authenticated
with check (user_id = auth.uid());

drop policy if exists "immo demand update admin" on public.demands;
create policy "immo demand update admin" on public.demands for update to authenticated
using (public.is_immo_admin()) with check (public.is_immo_admin());

drop policy if exists "immo message read participants" on public.messages;
create policy "immo message read participants" on public.messages for select to authenticated
using (public.is_immo_admin() or exists (
  select 1 from public.demands d where d.id = demand_id and d.user_id = auth.uid()
));

drop policy if exists "immo message send participants" on public.messages;
create policy "immo message send participants" on public.messages for insert to authenticated
with check (sender_id = auth.uid() and (
  public.is_immo_admin() or exists (
    select 1 from public.demands d where d.id = demand_id and d.user_id = auth.uid()
  )
));

-- Vérification minimale : doit retourner profiles, demands et messages.
select table_name from information_schema.tables
where table_schema = 'public' and table_name in ('profiles','demands','messages')
order by table_name;

-- Après inscription, attribuer l'administration avec la commande ci-dessous,
-- en remplaçant TON_EMAIL. À exécuter séparément dans SQL Editor :
-- update public.profiles set type_compte = 'admin'
-- where id = (select id from auth.users where email = 'TON_EMAIL');
